package com.online_transaction;

import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TransactionEJBClicnt {

	/**
	 * @param args
	 * @throws NamingException 
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NamingException, NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		TransactionBeanRemote obr = (TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		
		Transaction trans = new Transaction();
		
		System.out.println("Transaction ID:");
		int tid=Integer.parseInt(br.readLine());
		trans.setTransactionId(tid);
		
		System.out.println("Order ID:");
		int oid=Integer.parseInt(br.readLine());
		trans.setOrderId(oid);
		
		System.out.println("Customer Email:");
		String cid=br.readLine();
		trans.setCustomerEmail(cid);
		
		System.out.println("Total Price:");
		double totprice=Double.parseDouble(br.readLine());
		trans.setTotalPrice(totprice);
		
		System.out.println("Transaction Date:");
		String date=br.readLine();
		trans.setTransactionDate(date);
		
		try {
			obr.addNewTransaction(trans);
		} catch (SQLIntegrityConstraintViolationException e) {
			// TODO Auto-generated catch block
			System.out.println("Duplicate Key");
			e.printStackTrace();
		}
		
		System.out.println("Inserted into Database!");
		
		
	}

}
