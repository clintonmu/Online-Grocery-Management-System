package com.online_transaction;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="SHOPPINGTRANSACTION")
public class Transaction implements Serializable{

	int transactionId;
	int orderId;
	String customerEmail;
	double totalPrice;
	String transactionDate;
	
	@Id
	@Column(name="TRANSACTIONID")
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int tid) {
		this.transactionId = tid;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int oid) {
		this.orderId = oid;
	}
	
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	public Transaction(){}
	
}
