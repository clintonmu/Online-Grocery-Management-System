package com.online_transaction;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface TransactionBeanRemote {


	public void addNewTransaction(Transaction trans) throws SQLIntegrityConstraintViolationException;
	public Transaction searchTransaction(int transactionId);
	public List readAllTransactions();
	public void deleteTransaction(int transactionId);
   
	
	public Transaction updateTransaction(String transactionId, String orderId, 
			String customerId, double totalPrice, String transactionDate);

}
