package com.online_customers;

import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CustomerEJBClicnt {

	/**
	 * @param args
	 * @throws NamingException 
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NamingException, NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		CustomerBeanRemote cbr = (CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		Customer cs=new Customer();
		
		System.out.println("First Name:");
		String fname=br.readLine();
		cs.setCustomerFName(fname);
		
		System.out.println("Last Name:");
		String lname=br.readLine();
		cs.setCustomerLName(lname);
		
		System.out.println("Date of Birth:");
		String dob=br.readLine();
		cs.setDateOfBirth(dob);
		
		System.out.println("Address:");
		String add=br.readLine();
		cs.setCustomerAddress(add);
		
		System.out.println("Email/UserID");
		String email=br.readLine();
		cs.setCustomerEmail(email);
		
		System.out.println("Phone Number:");
		int phno=Integer.parseInt(br.readLine());
		cs.setCustomerPhoneNumber(phno);
		
		System.out.println("Password:");
		String pass=br.readLine();
		cs.setCustomerPassword(pass);
		
		System.out.println("Location:");
		String loc=br.readLine();
		cs.setCustomerLocation(loc);
		
		System.out.println("Date of Join:");
		String doj=br.readLine();
		cs.setDateOfJoin(doj);
		
		
		try {
			cbr.addNewCustomer(cs);
		} catch (SQLIntegrityConstraintViolationException e) {
			// TODO Auto-generated catch block
			System.out.println("Duplicate Key");
			e.printStackTrace();
		}
		
		System.out.println("Inserted into Database!");
		
		
	}

}
