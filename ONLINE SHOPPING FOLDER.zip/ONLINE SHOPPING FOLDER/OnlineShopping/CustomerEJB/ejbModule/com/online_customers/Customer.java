package com.online_customers;

import java.io.Serializable;

import javax.persistence.*;

@Entity(name="SHOPPINGCUSTOMER")
public class Customer implements Serializable{

	String customerFName;
	String customerLName;
	String dateOfBirth;
	String customerAddress;
	String customerEmail;
	int customerPhoneNumber;
	String customerPassword;
	String customerLocation;
	String dateOfJoin;

	
	public Customer(){}


	public String getCustomerFName() {
		return customerFName;
	}


	public void setCustomerFName(String customerFName) {
		this.customerFName = customerFName;
	}


	public String getCustomerLName() {
		return customerLName;
	}


	public void setCustomerLName(String customerLName) {
		this.customerLName = customerLName;
	}


	public String getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	@Id
	@Column (name="CUSTOMEREMAIL")
	public String getCustomerEmail() {
		return customerEmail;
	}


	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public int getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}


	public void setCustomerPhoneNumber(int customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}


	public String getCustomerPassword() {
		return customerPassword;
	}


	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}


	public String getCustomerLocation() {
		return customerLocation;
	}


	public void setCustomerLocation(String customerLocation) {
		this.customerLocation = customerLocation;
	}


	public String getDateOfJoin() {
		return dateOfJoin;
	}


	public void setDateOfJoin(String dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	
}
