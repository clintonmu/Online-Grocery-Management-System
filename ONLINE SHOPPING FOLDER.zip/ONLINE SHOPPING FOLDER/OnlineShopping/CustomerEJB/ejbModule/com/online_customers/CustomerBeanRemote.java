package com.online_customers;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface CustomerBeanRemote {

	public void addNewCustomer(Customer cust) throws SQLIntegrityConstraintViolationException;
	public void deleteCustomer(int customerId);
	public List readAllCustomers();
	public Customer searchCustomer(String customerEmail);	
	
	public Customer updateCustomer(String customerFName, String customerLName, 
			String dateOfBirth, String customerAddress, String customerEmail, 
			int customerPhoneNumber, String customerLocation,
			String dateOfJoin, int customerId);
	
	public String ValidateCustomer(String email, String pass);
}
