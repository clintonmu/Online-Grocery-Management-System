package com.online_customers;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.*;

/**
 * Session Bean implementation class CustomerBean
 */
@Stateless
public class CustomerBean implements CustomerBeanRemote {

    /**
     * Default constructor. 
     */
    public CustomerBean() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="CustomerUnit")
	EntityManager entityManager;

	@Override
	public void addNewCustomer(Customer cust)
			throws SQLIntegrityConstraintViolationException {
		entityManager.persist(cust);		
	}

	@Override
	public void deleteCustomer(String customerEmail) {
		entityManager.remove(entityManager.find(Customer.class, customerEmail));
		
	}

	@Override
	public List readAllCustomers() {
		// TODO Auto-generated method stub
		List allCustomers = entityManager.createQuery("FROM SHOPPINGCUSTOMER").getResultList();
		return allCustomers;	
	}

	public Customer searchCustomer(String customerEmail) {
		// TODO Auto-generated method stub
		Customer cust=entityManager.find(Customer.class, customerEmail);
		return cust;
	}
	
	@Override
	public Customer updateCustomer(String customerFName, String customerLName, 
			String dateOfBirth, String customerAddress, String customerEmail, 
			long customerPhoneNumber, String customerLocation,
			String dateOfJoin) {
		
		Customer cust=entityManager.find(Customer.class, customerEmail);
		if(cust!=null)
		{
			cust.setCustomerPassword(cust.customerPassword);
			cust.setDateOfJoin(cust.dateOfJoin);
			
			cust.setCustomerFName(customerFName);
			cust.setCustomerLName(customerLName);
			cust.setDateOfBirth(dateOfBirth);
			cust.setCustomerAddress(customerAddress);
			cust.setCustomerPhoneNumber(customerPhoneNumber);
			cust.setCustomerLocation(customerLocation);
			entityManager.merge(cust);
		}else
		{
			cust=null;
		}
		return cust;
	}
	
	
	public String ValidateCustomer(String email, String pass) {
		
		Customer cust=entityManager.find(Customer.class, email);
		String found = "false";
		
		if(cust!=null)
		{
			if(cust.getCustomerEmail().equals(email)&& cust.getCustomerPassword().equals(pass))
				found="true";
			else
				found= "false";
		}else{
			found="undefined";
		}
			return found;
	}

}
