package com.online_orders;

import java.io.Serializable;

import javax.persistence.*;

@Entity(name="SHOPPINGORDERS")
public class Order implements Serializable{

	int orderId;
	String orderDate;
	int customerId;
	String location;
	double totalPrice;
	double discount;
	double totalDiscountPrice;
	double netPrice;
	
	@Id
	@Column(name="ORDERID")
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int oid) {
		this.orderId = oid;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int cid) {
		this.customerId = cid;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getTotalDiscountPrice() {
		return totalDiscountPrice;
	}
	public void setTotalDiscountPrice(double totalDiscountPrice) {
		this.totalDiscountPrice = totalDiscountPrice;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	
	public Order(){}
	
}
