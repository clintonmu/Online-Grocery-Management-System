package com.online_orders;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Remote;


@Remote
public interface OrderBeanRemote {

	public Order addNewOrder(Order order) throws SQLIntegrityConstraintViolationException;
    public List readAllOrders();
	public Order searchOrder(int orderId);
	public void deleteOrder(int orderId);
   
	
	public Order updateOrder(int orderId, String orderDate,
			String location, double totalPrice, double discount,
			double totalDiscountPrice, double netPrice, String customerEmail);
	
	public List<Order> displayOrder(int orderId);

}
