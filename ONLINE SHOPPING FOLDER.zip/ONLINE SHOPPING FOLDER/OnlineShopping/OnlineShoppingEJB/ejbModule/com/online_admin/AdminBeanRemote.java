package com.online_admin;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.ejb.Remote;

import com.online_customers.Customer;

@Remote
public interface AdminBeanRemote {
	public void addNewAdmin(Admin admin) throws SQLIntegrityConstraintViolationException;
	public void deleteAdmin(String adminId);
	
	public String ValidateAdmin(String user, String pass);
}
