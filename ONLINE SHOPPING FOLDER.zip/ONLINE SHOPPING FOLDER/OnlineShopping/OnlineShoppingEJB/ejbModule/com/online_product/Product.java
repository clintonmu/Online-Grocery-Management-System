package com.online_product;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="SHOPPINGPRODUCT")
public class Product implements Serializable{
	int productId;
	String productName;
	String category;
	String productBrand;
	String productDescription;
	double productQuantity;
	double productPrice;
	double productStockQuantity;
	String dateOfAddition;
	
	@Id
	@Column(name="PRODUCTID")
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(double productQuantity) {
		this.productQuantity = productQuantity;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public double getProductStockQuantity() {
		return productStockQuantity;
	}
	public void setProductStockQuantity(double productStockQuantity) {
		this.productStockQuantity = productStockQuantity;
	}
	public String getDateOfAddition() {
		return dateOfAddition;
	}
	public void setDateOfAddition(String dateOfAddition) {
		this.dateOfAddition = dateOfAddition;
	}
	
	
	public Product(){}
	
}
