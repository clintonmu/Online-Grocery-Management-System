package com.online_product;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 * Session Bean implementation class ProductBean
 */
@Stateless
public class ProductBean implements ProductBeanRemote {

    /**
     * Default constructor. 
     */
    public ProductBean() {
        // TODO Auto-generated constructor stub
    }

    
    @PersistenceContext(name="ProductUnit")
    EntityManager entityManager;
    
	public void addNewProduct(Product prod) throws SQLIntegrityConstraintViolationException {
		entityManager.persist(prod);
		
	}

	
	public Product readProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}


	
	public void deleteProduct(int productId) {
		entityManager.remove(entityManager.find(Product.class, productId));
		
	}

	
	public List readAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Product updateProduct(int productId, String productName, String category,
			String productBrand, String productDescription, double productQuantity,
			double productPrice, double productStockQuantity, String dateOfAddition) {
		// TODO Auto-generated method stub
		Product prod=entityManager.find(Product.class, productId);
		if(prod!=null)
		{
			prod.setProductName(prod.productName);
			prod.setCategory(category);
			prod.setProductBrand(productBrand);
			prod.setProductDescription(productDescription);
			prod.setProductQuantity(productQuantity);
			prod.setProductPrice(productPrice);
			prod.setProductStockQuantity(productStockQuantity);
			prod.setDateOfAddition(prod.dateOfAddition);
			
			entityManager.merge(prod);
		}else
		{
			prod=null;
		}
		return prod;	
	}

}
