package com.online_customers;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.*;
/**
 * Session Bean implementation class CustomerBean
 */
@Stateless
public class CustomerBean implements CustomerBeanRemote {

    /**
     * Default constructor. 
     */
    public CustomerBean() {
        // TODO Auto-generated constructor stub
    }
    
    @PersistenceContext(name="CustomerUnit")
	EntityManager entityManager;

	@Override
	public void addNewCustomer(Customer cust)
			throws SQLIntegrityConstraintViolationException {
		entityManager.persist(cust);		
	}

	@Override
	public void deleteCustomer(int customerId) {
		entityManager.remove(entityManager.find(Customer.class, customerId));
		
	}

	@Override
	public List readAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer searchCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Customer updateCustomer(String customerFName, String customerLName, 
			String dateOfBirth, String customerAddress, String customerEmail, 
			int customerPhoneNumber, String customerLocation,
			String dateOfJoin, int customerId) {
		
		Customer cust=entityManager.find(Customer.class, customerEmail);
		if(cust!=null)
		{
			cust.setCustomerPassword(cust.customerPassword);
			cust.setDateOfJoin(cust.dateOfJoin);
			cust.setCustomerId(cust.customerId);
			
			cust.setCustomerFName(customerFName);
			cust.setCustomerLName(customerLName);
			cust.setDateOfBirth(dateOfBirth);
			cust.setCustomerAddress(customerAddress);
			cust.setCustomerPhoneNumber(customerPhoneNumber);
			cust.setCustomerLocation(customerLocation);
			entityManager.merge(cust);
		}else
		{
			cust=null;
		}
		return cust;
	}

}
