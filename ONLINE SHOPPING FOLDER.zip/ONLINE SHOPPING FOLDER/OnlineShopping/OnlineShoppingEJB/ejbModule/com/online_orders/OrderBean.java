package com.online_orders;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.online_customers.Customer;

/**
 * Session Bean implementation class OrderBean
 */
@Stateless
public class OrderBean implements OrderBeanRemote {

    /**
     * Default constructor. 
     */
    public OrderBean() {
        // TODO Auto-generated constructor stub
    }

    @PersistenceContext(name="OrderUnit")
    EntityManager entityManager;
    
	@Override
	public void addNewOrder(Order order)
			throws SQLIntegrityConstraintViolationException {
		entityManager.persist(order);
		
	}

	@Override
	public Order readOrder(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteOrder(int orderId) {
		entityManager.remove(entityManager.find(Order.class, orderId));
		
	}

	@Override
	public List readAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order updateOrder(String orderId, String orderDate, String transactionId,
			String customerId, String location, double totalPrice, double discount,
			double totalDiscountPrice, double netPrice) {
		// TODO Auto-generated method stub
		Order ord=entityManager.find(Order.class, orderId);
		if(ord!=null)
		{
			ord.setOrderDate(orderDate);
			ord.setTransactionId(ord.transactionId);
			ord.setCustomerId(ord.customerId);
			ord.setLocation(location);
			ord.setTotalPrice(totalPrice);
			
			//calculating discount
			double disc=discount/100;
			ord.setDiscount(disc);
			
			//calculating discounted price
			totalDiscountPrice=totalPrice*disc;
			ord.setTotalDiscountPrice(totalDiscountPrice);
			
			//calculating net price
			netPrice=totalPrice-totalDiscountPrice;
			ord.setNetPrice(netPrice);
			
			entityManager.merge(ord);
		}else
		{
			ord=null;
		}
		return ord;	
		
	}

}
