 package com.online_customers;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CustomerBean {
	String fname;
	String lname;
	String dob;
	String address;
	String email;
	long phnumber;
	String password;
	String location;
	String doj;
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhnumber() {
		return phnumber;
	}

	public void setPhnumber(long phnumber) {
		this.phnumber = phnumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public Properties getP() {
		return p;
	}

	public void setP(Properties p) {
		this.p = p;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	Properties p=new Properties();
	String msg="";
	
	
	public CustomerBean() throws NamingException
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		
	}
	
	public String delete() throws NamingException
	{	Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		Customer cust=Cbr.searchCustomer(this.email);
		if(cust!=null)
		{
			Cbr.deleteCustomer(this.email);
			return "SuccessDeleteCustomer";
		}
		else
			return "FailDelete";
		
	}

	public String add() throws NamingException, SQLIntegrityConstraintViolationException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		System.out.println("Setting details:");
		Customer cust=new Customer();
		cust.setCustomerFName(this.fname);
		cust.setCustomerLName(this.lname);
		cust.setDateOfBirth(this.dob);
		cust.setCustomerAddress(this.address);
		cust.setCustomerEmail(this.email);
		cust.setCustomerPhoneNumber(this.phnumber);
		cust.setCustomerPassword(this.password);
		cust.setCustomerLocation(this.location);
		cust.setDateOfJoin(this.doj);
		System.out.println("Details set!");
		
		Customer ct=Cbr.searchCustomer(this.email);
		if(ct==null)
		{
			System.out.println("details:"+this.fname+", "+this.lname);
			Cbr.addNewCustomer(cust);
			msg= "SuccessAddCustomer"; 
		}else{
			msg= "FailAdd";
		}
		System.out.println("returning: "+msg);
		return msg;
	}
	
	
	public String update() throws NamingException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		Customer cust=new Customer();
		cust.getCustomerFName();
		cust.getCustomerLName();
		cust.getDateOfBirth();
		cust.getCustomerAddress();
		cust.getCustomerEmail();
		cust.getCustomerPhoneNumber();
		cust.getCustomerPassword();
		cust.getCustomerLocation();
		cust.getDateOfJoin();
		
		Customer ct=Cbr.searchCustomer(this.email);
		if(ct!=null)
		{
			Cbr.updateCustomer(this.fname, this.lname, this.dob, this.address, this.email, 
					this.phnumber, this.password, this.location, this.doj);
			return "SuccessUpdateCustomer";
		}else
			return "FailUpdate";
	}
	
	public String search() throws NamingException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		Customer cust=Cbr.searchCustomer(this.email);
		
		if(cust!=null)
		{
			return "SuccessSearchCustomer";
		}else
			return "FailSearch";
	}
	
}
