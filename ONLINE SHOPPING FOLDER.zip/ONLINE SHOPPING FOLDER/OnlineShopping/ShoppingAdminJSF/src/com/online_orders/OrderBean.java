package com.online_orders;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

import com.online_customers.Customer;
import com.online_customers.CustomerBeanRemote;
import com.online_product.Product;
import com.online_product.ProductBeanRemote;

public class OrderBean {
	int orderId;
	String orderDate;
	String location;
	double totalPrice;
	double discount;
	double totalDiscountPrice;
	double netPrice;
	String customerEmail;
	double totdiscprice=0.0;
	double netprice=0.0;
	
	public int getOrderId() {
		return orderId;
	}
	public double getTotdiscprice() {
		return totdiscprice;
	}
	public void setTotdiscprice(double totdiscprice) {
		this.totdiscprice = totdiscprice;
	}
	public double getNetprice() {
		return netprice;
	}
	public void setNetprice(double netprice) {
		this.netprice = netprice;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getTotalDiscountPrice() {
		return totalDiscountPrice;
	}
	public void setTotalDiscountPrice(double totalDiscountPrice) {
		this.totalDiscountPrice = totalDiscountPrice;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	
	Properties p=new Properties();
	String msg="";
	
	public OrderBean()
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
	}
	
	public String add() throws NamingException, SQLIntegrityConstraintViolationException
	{
		
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		// This line is used to transform the data entered by the user in JSP
		// into this Java Object
		Order ord=new Order();
		ord.setOrderId(this.orderId);
		ord.setOrderDate(this.orderDate);
		ord.setLocation(this.location);
		ord.setTotalPrice(this.totalPrice);
		ord.setDiscount(this.discount);
		ord.setCustomerEmail(this.customerEmail);
		
		
		System.out.println(this.orderId+", "+this.orderDate+", "+this.location);
		System.out.println(this.totalPrice+", "+this.discount+", "+this.totalDiscountPrice);
		System.out.println(this.netPrice+", "+this.customerEmail);
		
		//problem to be solved! No display of calculated values
		Order ord1=obr.searchOrder(this.orderId);
		if(ord1==null)
		{
			Order or=obr.addNewOrder(ord);
			this.setTotalDiscountPrice(or.totalDiscountPrice);
			this.setNetprice(or.netPrice);
			System.out.println(this.totalDiscountPrice+", "+this.netPrice);
			msg= "SuccessAddOrder";
		}else
			msg= "FailAdd";
		
		System.out.println("returning: "+msg);
		return msg;
	}
	
	public String delete() throws NamingException
	{
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		Order ord=obr.searchOrder(this.orderId);
		if(ord!=null)
		{
			obr.deleteOrder(this.orderId);
			msg= "SuccessDeleteOrder";
		}
		else
			msg= "FailDelete";
		
		return msg;
		
	}
	
	public String update() throws NamingException
	{
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		Order ord=new Order();
		
		ord.getOrderId();
		ord.getOrderDate();
		ord.getLocation();
		ord.getTotalPrice();
		ord.getDiscount();
		ord.getTotalDiscountPrice();
		ord.getNetPrice();
		ord.getCustomerEmail();

		Order ord1=obr.searchOrder(this.orderId);
		if(ord1!=null)
		{
			obr.updateOrder(this.orderId, this.orderDate, this.location, this.totalPrice, this.discount,
					this.totalDiscountPrice, this.netPrice, this.customerEmail);
			return "SuccessUpdateOrder";
		}else
			return "FailUpdate";
	}
	
	
	public String search() throws NamingException
	{
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		Order ord=obr.searchOrder(this.orderId);
		
		if(ord!=null)
		{
			return "SuccessSearchOrder";
		}else
			return "FailSearch";
	}
}

