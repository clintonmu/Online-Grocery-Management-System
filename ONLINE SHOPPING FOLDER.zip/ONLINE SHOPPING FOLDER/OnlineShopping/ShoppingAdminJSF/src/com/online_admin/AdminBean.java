 package com.online_admin;

import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class AdminBean {
	String username;
	String password;

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public AdminBean()
	{}
	
	public String login() throws NamingException
	{
		String msg="";
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		AdminBeanRemote abr=(AdminBeanRemote) ctx.lookup("AdminBean/remote");
		
		String val=abr.ValidateAdmin(this.username.toUpperCase(), this.password.toUpperCase());
			if(val.equals("true"))
			{
				msg="Successful";
				FacesContext fc = FacesContext.getCurrentInstance();
				ExternalContext ec=fc.getExternalContext();
				HttpSession hps=(HttpSession) ec.getSession(false);
				hps.setAttribute("username",this.username);
			}
			else
			{
				msg="Fail";
			}
		return msg;
	}
	
//	public String logout()
//	{
//		FacesContext fc = FacesContext.getCurrentInstance();
//		ExternalContext ec=fc.getExternalContext();
//		HttpSession hps=(HttpSession) ec.getSession(false);
//		String msg="";
//		
//		if(hps!=null)
//
//		{
//			String x=(String)hps.getAttribute("username");
//			if(x!=null)
//			{
//				hps.removeAttribute("username");
//				hps.invalidate();
//				msg="loggedout";
//			}
//		}
//		return msg;
//	}
}
