package javabeat.net.script;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 * Load Script File Example
 *
 * @author Krishna
 *
 */
public class test1 {
	public static void main(String[] args) throws ScriptException,
			FileNotFoundException, NoSuchMethodException {

		// Create ScriptEngineManager
		ScriptEngineManager engineManager = new ScriptEngineManager();

		// Create ScriptEngine
		ScriptEngine engine = engineManager.getEngineByName("ECMAScript");

		//Create file and reader instance for reading the script file
		File file = new File("Eval.js");
		Reader reader = new FileReader(file);

		//Pass the script file to the engine
		engine.eval(reader);
		System.out.println("Java Program Output");
		//Create invocable instance
		Invocable invocable = (Invocable) engine;

		//Invoke the methods defined in the script file
		invocable.invokeFunction("firstFn", "Eval.js");

	}
}