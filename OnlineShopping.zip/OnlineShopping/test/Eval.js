println("Loaded the scripts");

function firstFn(name){

    println("This Method written in script file : "+name);

}
