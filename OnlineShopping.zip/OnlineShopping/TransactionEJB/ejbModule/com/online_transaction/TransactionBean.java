package com.online_transaction;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 * Session Bean implementation class TransactionBean
 */
@Stateless
public class TransactionBean implements TransactionBeanRemote {

    /**
     * Default constructor. 
     */
    public TransactionBean() {
        // TODO Auto-generated constructor stub
    }

    @PersistenceContext(name="TransactionUnit")
    EntityManager entityManager;
    
	@Override
	public void addNewTransaction(Transaction trans)
			throws SQLIntegrityConstraintViolationException {
		entityManager.persist(trans);
		
	}

	@Override
	public Transaction searchTransaction(int transactionId) {
		// TODO Auto-generated method stub
		Transaction trans=entityManager.find(Transaction.class, transactionId);
		return trans;
	}

	@Override
	public List readAllTransactions() {
		// TODO Auto-generated method stub
		List allTransactions = entityManager.createQuery("FROM SHOPPINGTRANSACTION").getResultList();
		return allTransactions;
	}

	@Override
	public void deleteTransaction(int transactionId) {
		entityManager.remove(entityManager.find(Transaction.class, transactionId));
		
	}

	@Override
	public Transaction updateTransaction(int transactionId, int orderId, 
			double totalPrice, String transactionDate, String customerEmail) {
		// TODO Auto-generated method stub
		Transaction trans=entityManager.find(Transaction.class, transactionId);
		if(trans!=null)
		{
			trans.setCustomerEmail(trans.customerEmail);
			trans.setOrderId(trans.orderId);
			trans.setTotalPrice(totalPrice);
			trans.setTransactionDate(trans.transactionDate);
			
			entityManager.merge(trans);
		}else
		{
			trans=null;
		}
		return trans;
	}

	@Override
	public List<Transaction> displayTransaction(int transactionId) {
		@SuppressWarnings("unchecked")
		List<Transaction> allTransactions=entityManager.createQuery("From SHOPPINGTRANSACTION").getResultList();
	
		List<Transaction> searchResult = new ArrayList<Transaction>();
		   if(allTransactions!=null)
		   {
		   for (Transaction transaction:allTransactions) 
		   {
		     if(transaction.getTransactionId()==transactionId)
		     {
		      searchResult.add(transaction);
		      }
		   }
		   }
		   return searchResult;
	}

}
