package com.online_orders;
import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.*;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.script.ScriptException;

public class OrderBean {
	int orderId;
	String orderDate;
	String location;
	double totalPrice;
	double discount;
	double totalDiscountPrice;
	double netPrice;
	String customerEmail;
	double totdiscprice=0.0;
	double netprice=0.0;
	List<Order> list=new ArrayList<Order>();
	int quantity;
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getOrderId() {
		return orderId;
	}
	public double getTotdiscprice() {
		return totdiscprice;
	}
	public void setTotdiscprice(double totdiscprice) {
		this.totdiscprice = totdiscprice;
	}
	public double getNetprice() {
		return netprice;
	}
	public void setNetprice(double netprice) {
		this.netprice = netprice;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getTotalDiscountPrice() {
		return totalDiscountPrice;
	}
	public void setTotalDiscountPrice(double totalDiscountPrice) {
		this.totalDiscountPrice = totalDiscountPrice;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public List<Order> getList() {
		return list;
	}
	public void setList(List<Order> list) {
		this.list = list;
	}
	
	Properties p=new Properties();
	String msg="";
	
	public OrderBean()
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
	}
	
	public String add() throws NamingException, SQLIntegrityConstraintViolationException, ScriptException, FileNotFoundException, NoSuchMethodException
	{
		
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		// This line is used to transform the data entered by the user in JSP
		// into this Java Object
		
		Order ord=new Order();

		//Getting order Id
		int max=0;
		@SuppressWarnings("unchecked")
		List<Order> set=obr.readAllOrders();
		for (int i = 0; i < set.size(); i++) {
			ord=set.get(i);
			int x=ord.getOrderId();
			if(x>max)
				max=x;
		}
	
			
		System.out.println(totalPrice);
		//getting order date
		Calendar cal=Calendar.getInstance();
		Date d=cal.getTime();
		String newdate=d.getDate()+"-"+(d.getMonth()+1)+"-"+(d.getYear()+1900);
		System.out.println(newdate);
		
		ord.setOrderId(max+3);
		ord.setOrderDate(newdate);
		ord.setLocation("Bangalore");
		ord.setTotalPrice(this.totalPrice);
		
		ord.setDiscount(10);

		
		ord.setCustomerEmail("doreen@gmail.com");

		System.out.println(this.orderId+", "+this.orderDate+", "+this.location);
		System.out.println(this.totalPrice+", "+this.discount+", "+this.totalDiscountPrice);
		System.out.println(this.netPrice+", "+this.customerEmail);
		
		//problem to be solved! No display of calculated values
		Order ord1=obr.searchOrder(this.orderId);
		if(ord1==null)
		{
			Order or=obr.addNewOrder(ord);
			this.setTotalDiscountPrice(or.totalDiscountPrice);
			this.setNetprice(or.netPrice);
			System.out.println(this.totalDiscountPrice+", "+this.netPrice);
			msg= "SuccessAddOrder";
		}else
			msg= "FailAdd";
		
		System.out.println("returning: "+msg);
		return msg;
	}
	
	public String delete() throws NamingException
	{
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		Order ord=obr.searchOrder(this.orderId);
		if(ord!=null)
		{
			obr.deleteOrder(this.orderId);
			msg= "SuccessDeleteOrder";
		}
		else
			msg= "FailDelete";
		
		return msg;
	}
	
	public String update() throws NamingException
	{
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		Order ord=new Order();
		
		ord.getOrderId();
		ord.getOrderDate();
		ord.getLocation();
		ord.getTotalPrice();
		ord.getDiscount();
		ord.getTotalDiscountPrice();
		ord.getNetPrice();
		ord.getCustomerEmail();

		Order ord1=obr.searchOrder(this.orderId);
		if(ord1!=null)
		{
			obr.updateOrder(this.orderId, this.orderDate, this.location, this.totalPrice, this.discount,
					this.totalDiscountPrice, this.netPrice, this.customerEmail);
			return "SuccessUpdateOrder";
		}else
			return "FailUpdate";
	}
	
	public String search() throws NamingException
	{
		Context ctx=new InitialContext(p);
		OrderBeanRemote obr=(OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		list=obr.displayOrder(this.orderId);
		
		if(!list.isEmpty())
		{
			return "SuccessSearchOrder";
		}else
			return "FailSearch";
	}
}

