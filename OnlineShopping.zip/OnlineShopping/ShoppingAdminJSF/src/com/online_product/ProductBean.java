package com.online_product;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;


public class ProductBean {
	int prodId;
	String prodName;
	String category;
	String brand;
	String description;
	double qty;
	double price;
	double stockqty;
	String doa;
	List<Product> list=new ArrayList<Product>();
	String[] checkBox;
	private Map<Long, Boolean> checked = new HashMap<Long, Boolean>();
    private List<Product> items;

	public Map<Long, Boolean> getChecked() {
		return checked;
	}
	public void setChecked(Map<Long, Boolean> checked) {
		this.checked = checked;
	}
	public List<Product> getItems() {
		return items;
	}
	public void setItems(List<Product> items) {
		this.items = items;
	}
	public String[] getCheckBox() {
		return checkBox;
	}
	public void setCheckBox(String[] checkBox) {
		this.checkBox = checkBox;
	}
	public List<Product> getList() {
		return list;
	}
	public void setList(List<Product> list) {
		this.list = list;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getQty() {
		return qty;
	}
	public void setQty(double qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getStockqty() {
		return stockqty;
	}
	public void setStockqty(double stockqty) {
		this.stockqty = stockqty;
	}
	public String getDoa() {
		return doa;
	}
	public void setDoa(String doa) {
		this.doa = doa;
	}
	
	Properties p=new Properties();
	String msg="";
	
	public ProductBean()
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");

	}
	
	public String delete() throws NamingException
	{
		Context ctx=new InitialContext(p);
		ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
		
		Product prod=pbr.searchProduct(this.prodId);
		if(prod!=null)
		{
			pbr.deleteProduct(this.prodId);
			return "SuccessDeleteProduct";
		}
		else
			return "FailDelete";
	}
	
	public String add() throws SQLIntegrityConstraintViolationException, NamingException
	{
		Context ctx=new InitialContext(p);
		ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
		
		Product prod=new Product();
		prod.setProductId(this.prodId);
		prod.setProductName(this.prodName);
		prod.setCategory(this.category);
		prod.setProductBrand(this.brand);
		prod.setProductDescription(this.description);
		prod.setProductQuantity(this.qty);
		prod.setProductPrice(this.price);
		prod.setProductStockQuantity(this.stockqty);
		prod.setDateOfAddition(this.doa);
		
		
		Product prod1=pbr.searchProduct(this.prodId);
		if(prod1==null)
		{
			pbr.addNewProduct(prod);
			msg= "SuccessAddProduct";
		}else
			msg= "FailAdd";
		
		System.out.println("returning: "+msg);
		return msg;
	}
	
	public String update() throws NamingException
	{
		Context ctx=new InitialContext(p);
		ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
		
		Product prod=new Product();
		prod.getProductId();
		prod.getProductName();
		prod.getCategory();
		prod.getProductBrand();
		prod.getProductDescription();
		prod.getProductQuantity();
		prod.getProductPrice();
		prod.getProductStockQuantity();
		prod.getDateOfAddition();
		
		Product prod1=pbr.searchProduct(this.prodId);
		if(prod1!=null)
		{
			pbr.updateProduct(this.prodId, this.prodName, this.category, this.brand, this.description,
					this.qty, this.price, this.stockqty, this.doa);
			return "SuccessUpdateProduct";
		}else
			return "FailUpdate";
	}
	
	
	public String search() throws NamingException
	{
		Context ctx=new InitialContext(p);
		ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
		
		list=pbr.displayProduct(this.prodId);
		
		if(!list.isEmpty())
		{
			pbr.searchProduct(this.prodId);
			return "SuccessSearchProduct";
		}else
			return "FailSearch";
	}
	
	public String read() throws NamingException
	{
		Context ctx=new InitialContext(p);
		ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
		

		this.list=pbr.readAllProducts();
		if(this.list!=null)
		{
			return "ReadProduct";
		}else
			return "FailSearch";
		
	}
	
	
	public String addProduct() 
	{
		for (int i = 0; i < checkBox.length; i++) {
			System.out.println(checkBox[i]);

		}
		return "CheckoutProduct";
		
	}	
		

	 public String submit() throws NamingException {
		 Context ctx=new InitialContext(p);
			ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
			
			int x=Integer.parseInt(checkBox[0]);
			list=pbr.displayProduct(x);
			
			if(!list.isEmpty())
			{
				pbr.searchProduct(this.prodId);
			 	 return "CheckoutProduct";
			}else
				return "FailSearch";

	    }
	 
		
}
