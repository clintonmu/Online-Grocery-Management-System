package com.online_transaction;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;



public class TransactionBean {
	int transactionId;
	int orderId;
	double totalPrice;
	String transactionDate;
	String customerEmail;
	List<Transaction> list=new ArrayList<Transaction>();

	
	public List<Transaction> getList() {
		return list;
	}
	public void setList(List<Transaction> list) {
		this.list = list;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	Properties p=new Properties();
	String msg="";

	public TransactionBean()
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
	}
	
	public String delete() throws NamingException
	{
		Context ctx=new InitialContext(p);
		TransactionBeanRemote tbr=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		
		Transaction trans=tbr.searchTransaction(this.transactionId);
		
		if(trans!=null)
		{
			tbr.deleteTransaction(this.transactionId);
			return "SuccessDeleteTransaction";
		}
		else
			return "FailDelete";
	}
	
	public String add() throws SQLIntegrityConstraintViolationException, NamingException
	{
		Context ctx=new InitialContext(p);
		TransactionBeanRemote tbr=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		
		Transaction trans=new Transaction();
		
		trans.setTransactionId(this.transactionId);
		trans.setOrderId(this.orderId);
		trans.setTotalPrice(this.totalPrice);
		trans.setTransactionDate(this.transactionDate);
		trans.setCustomerEmail(this.customerEmail);
		
		Transaction trans1=tbr.searchTransaction(this.transactionId);
		if(trans1==null)
		{
			tbr.addNewTransaction(trans);
			msg= "SuccessAddTransaction";
		}else
			msg= "FailAdd";
		
		System.out.println("returning: "+msg);
		return msg;
	}
	
	public String update() throws NamingException
	{
		Context ctx=new InitialContext(p);
		TransactionBeanRemote tbr=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		
		Transaction trans=new Transaction();
		
		trans.getTransactionId();
		trans.getOrderId();
		trans.getTotalPrice();
		trans.getTransactionDate();
		trans.getCustomerEmail();
		
		Transaction trans1=tbr.searchTransaction(this.transactionId);
		if(trans1!=null)
		{
			tbr.updateTransaction(this.transactionId, this.orderId, this.totalPrice, this.transactionDate,
					this.customerEmail);
			return "SuccessUpdateTransaction";
		}else
			return "FailUpdate";
	}
	
	
	public String search() throws NamingException
	{
		Context ctx=new InitialContext(p);
		TransactionBeanRemote tbr=(TransactionBeanRemote) ctx.lookup("TransactionBean/remote");
		
		list=tbr.displayTransaction(this.transactionId);
		
		if(!list.isEmpty())
		{
			return "SuccessSearchTransaction";
		}else
			return "FailSearch";
	}
	
}
