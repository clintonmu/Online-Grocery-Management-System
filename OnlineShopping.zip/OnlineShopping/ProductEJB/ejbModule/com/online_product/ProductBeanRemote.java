package com.online_product;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

import javax.ejb.Remote;


@Remote
public interface ProductBeanRemote {

	public void addNewProduct(Product prod) throws SQLIntegrityConstraintViolationException;
	public Product searchProduct(int productId);
	public List readAllProducts();
	public void deleteProduct(int productId);
	
	
	public Product updateProduct(int productId, String productName, String category,
		String productBrand, String productDescription, double productQuantity,
		double productPrice, double productStockQuantity, String dateOfAddition);
	
	public List<Product> displayProduct(int productId);

}
