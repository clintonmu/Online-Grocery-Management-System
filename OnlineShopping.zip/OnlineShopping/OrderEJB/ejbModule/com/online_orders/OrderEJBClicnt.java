package com.online_orders;

import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class OrderEJBClicnt {

	/**
	 * @param args
	 * @throws NamingException 
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NamingException, NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		OrderBeanRemote obr = (OrderBeanRemote) ctx.lookup("OrderBean/remote");
		
		Order ord=new Order();
		
//		System.out.println("Order ID:");
//		int oid=Integer.parseInt(br.readLine());
//		ord.setOrderId(oid);
//		
//		System.out.println("Order Date:");
//		String date=br.readLine();
//		ord.setOrderDate(date);
//		
//		
//		System.out.println("Location:");
//		String loc=br.readLine();
//		ord.setLocation(loc);
//		
//		System.out.println("Total Price:");
//		double totprice=Double.parseDouble(br.readLine());
//		ord.setTotalPrice(totprice);
//		
//		System.out.println("Discount:");
//		double dis=Double.parseDouble(br.readLine());
//		ord.setDiscount(dis);
//		
//		System.out.println("Calculating discounted price...");
//		double disp=totprice*(dis/100);
//		ord.setTotalDiscountPrice(disp);
//		
//		System.out.println("Calculating Net Price...");
//		double net=totprice-disp;
//		ord.setNetPrice(net);
//		
//		
//		try {
//			obr.addNewOrder(ord);
//		} catch (SQLIntegrityConstraintViolationException e) {
//			// TODO Auto-generated catch block
//			System.out.println("Duplicate Key");
//			e.printStackTrace();
//		}
//		
//		System.out.println("Inserted into Database!");
		int max=0;
		List<Order> set=obr.readAllOrders();
		for (int i = 0; i < set.size(); i++) {
			ord=set.get(i);
			System.out.println(ord.getOrderId());
			int x=ord.getOrderId();
			if(x>max)
			{
				max=x;
			}
		}
		
		System.out.println("Largest ID: "+max);
			
		Calendar cal=Calendar.getInstance();
		Date d=cal.getTime();
		String newdate=d.getDate()+"-"+(d.getMonth()+1)+"-"+(d.getYear()+1900);
		System.out.println(newdate);
		
		
	}

}
