package com.grocery_project;

public class Orders {
		
	String OrderId;
	String productId;
	String transactionId;
	String productName;
	double productQuantity;
	double productPrice;
	String customerId;
	String location;
	double discount;
	double total_Discounted_Price;
	double netPrice;
	String order_Date;

	public Orders() {
		super();
	}
	
	
	public String getOrderId() {
		return OrderId;
	}
	public void setOrderId(String orderId) {
		OrderId = orderId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(double productQuantity) {
		this.productQuantity = productQuantity;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public double getTotal_Discounted_Price() {
		return total_Discounted_Price;
	}
	public void setTotal_Discounted_Price(double total_Discounted_Price) {
		this.total_Discounted_Price = total_Discounted_Price;
	}
	public double getNetPrice() {
		return netPrice;
	}
	public void setNetPrice(double netPrice) {
		this.netPrice = netPrice;
	}
	public String getOrder_Date() {
		return order_Date;
	}
	public void setOrder_Date(String order_Date) {
		this.order_Date = order_Date;
	}
	
	
	
	public void serOrdersDetails(Orders o)
	{
		this.OrderId=o.OrderId;
		this.productId=o.productId;
		this.transactionId=o.transactionId;
		this.productName=o.productName;
		this.productQuantity=o.productQuantity;
		this.productPrice=o.productPrice;
		this.customerId=o.customerId;
		this.location=o.location;
		this.discount=o.discount;
		this.total_Discounted_Price=o.total_Discounted_Price;
		this.netPrice=o.netPrice;
		this.order_Date=o.order_Date;
	}
		
	
}
