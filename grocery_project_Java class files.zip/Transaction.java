package com.grocery_project;

public class Transaction {
	
	String transactionId;
	String orderId;
	String customerId;
	double totalPrice;
	String transaction_date;
	
	public Transaction() {
		super();
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public double getTotaiPrice() {
		return totalPrice;
	}
	public void setTotaiPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}
	
	public void setTransactionDetails(Transaction t)
	{
		this.transactionId=t.transactionId;
		this.orderId=t.orderId;
		this.customerId=t.customerId;
		this.totalPrice=t.totalPrice;
		this.transaction_date=t.transaction_date;
	}
	

}
