package com.grocery_project;

public class Retailer {
	
	String retailerId;
	String productId;
	String loginId;
	String loginPassword;
	int date_of_Addition;

	
	public Retailer()
	{
		super();
	}
	public String getRetailerId() {
		return retailerId;
	}
	public void setRetailerId(String retailerId) {
		this.retailerId = retailerId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public int getDate_of_Addition() {
		return date_of_Addition;
	}
	public void setDate_of_Addition(int date_of_Addition) {
		this.date_of_Addition = date_of_Addition;
	}
	
	public void retailerDetails(Retailer r)
	{
		this.retailerId=r.retailerId;
		this.productId=r.productId;
		this.loginId=r.loginId;
		this.loginPassword=r.loginPassword;
		this.date_of_Addition=r.date_of_Addition;
	}
	
}
