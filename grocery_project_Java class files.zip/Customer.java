package com.grocery_project;

public class Customer {
	
	String customerId;
	String customerFirstName;
	String customerLastName;
	String date_of_Join;
	String address;
	String email;
	int phoneNumber;
	String userId;
	String password;
	String orderId;
	String location;
	
	
	public Customer() {
		super();
	}
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerFirstName() {
		return customerFirstName;
	}
	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public String getDate_of_Join() {
		return date_of_Join;
	}
	public void setDate_of_Join(String date_of_Join) {
		this.date_of_Join = date_of_Join;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public void setCustomerDetails(Customer c)
	{
		this.customerId=c.customerId;
		this.customerFirstName=c.customerFirstName;
		this.customerLastName=c.customerLastName;
		this.date_of_Join=c.date_of_Join;
		this.address=c.address;
		this.email=c.email;
		this.phoneNumber=c.phoneNumber;
		this.userId=c.userId;
		this.password=c.password;
		this.orderId=c.userId;
		this.location=c.location;
	}


}
