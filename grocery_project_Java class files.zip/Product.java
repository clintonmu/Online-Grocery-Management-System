package com.grocery_project;

public class Product {
	
	
	public Product()
	{
		super();
	}
	String productId;
	String retailerId;
	String productName;
	String productCategory;
	String productBrand;
	String productDescription;
	double productQuantity;
	double productPrice;
	double productStockQuantity;
	int date_of_Addititon;
	
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getRetailerId() {
		return retailerId;
	}
	public void setRetailerId(String retailerId) {
		this.retailerId = retailerId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public double getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(double productQuantity) {
		this.productQuantity = productQuantity;
	}
	
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public double getProductStockQuantity() {
		return productStockQuantity;
	}
	public void setProductStockQuantity(double productStockQuantity) {
		this.productStockQuantity = productStockQuantity;
	}
	public int getDate_of_Addititon() {
		return date_of_Addititon;
	}
	public void setDate_of_Addititon(int date_of_Addititon) {
		this.date_of_Addititon = date_of_Addititon;
	}
	
	public void setProductDetails(Product p)
	{
		this.productId=p.productId;
		this.retailerId=p.retailerId;
		this.productName=p.productName;
		this.productCategory=p.productCategory;
		this.productBrand=p.productBrand;
		this.productDescription=p.productDescription;
		this.productQuantity=p.productQuantity;
		this.productPrice=p.productPrice;
		this.productStockQuantity=p.productStockQuantity;
		this.date_of_Addititon=p.date_of_Addititon;
	}
	

}
