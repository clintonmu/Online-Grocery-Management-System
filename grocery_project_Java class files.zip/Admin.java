package com.grocery_project;

public class Admin {
	
	public Admin() 
	{
		super();
	}
	String adminId;
	String userName;
	String password;
	int date_of_Creation;
	
	
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getDate_of_Creation() {
		return date_of_Creation;
	}
	public void setDate_of_Creation(int date_of_Creation) {
		this.date_of_Creation = date_of_Creation;
	}
	
	public void adminDetails(Admin a)
	{
		this.adminId=a.adminId;
		this.userName=a.userName;
		this.password=a.password;
		this.date_of_Creation=a.date_of_Creation;
	}
	

}
