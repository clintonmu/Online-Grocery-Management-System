package com.online_admin;

import java.sql.SQLIntegrityConstraintViolationException;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 * Session Bean implementation class AdminBean
 */
@Stateless
public class AdminBean implements AdminBeanRemote {

    /**
     * Default constructor. 
     */
    public AdminBean() {
        // TODO Auto-generated constructor stub
    }

    @PersistenceContext(name="AdminUnit")
    EntityManager entityManager;
    		
	
	public String ValidateAdmin(String user, String pass) {
		
			Admin admin=entityManager.find(Admin.class, user);
			String found = "false";
			
			if(admin!=null)
			{
				if(admin.getUsername().equals(user)&& admin.getPassword().equals(pass))
					found="true";
				else
					found= "false";
			}else{
				found="undefined";
			}
				return found;
		}

	
	public void addNewAdmin(Admin admin)
			throws SQLIntegrityConstraintViolationException {
		entityManager.persist(admin);			
	}

	
	public void deleteAdmin(String adminId) {
		entityManager.remove(entityManager.find(Admin.class, adminId));
	}

}
