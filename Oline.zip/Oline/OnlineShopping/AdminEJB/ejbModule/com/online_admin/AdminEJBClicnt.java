package com.online_admin;

import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class AdminEJBClicnt {

	/**
	 * @param args
	 * @throws NamingException 
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NamingException, NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		AdminBeanRemote abr = (AdminBeanRemote) ctx.lookup("AdminBean/remote");
		
		Admin ad=new Admin();
		
		System.out.println("Username:");
		String username=br.readLine();
		ad.setUsername(username);
		System.out.println("Password:");
		String password=br.readLine();
		ad.setPassword(password); 
		String date="19-08-2016";
		ad.setDateOfCreation(date);
		try {
			abr.addNewAdmin(ad);
		} catch (SQLIntegrityConstraintViolationException e) {
			// TODO Auto-generated catch block
			System.out.println("Duplicate Key");
			e.printStackTrace();
		}
		
		System.out.println("Inserted into Database!");
		
		
	}

}
