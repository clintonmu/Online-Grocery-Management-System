package com.online_product;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class ProductListBean {

	ProductBean arr[];
	float sum;
	//List<Product> listProduct;
	List<Product> list=new ArrayList<Product>();


	public ProductBean[] getArr() {
		return arr;
	}

	public void setArr(ProductBean[] arr) {
		this.arr = arr;
	}
	
	public List<Product> getList() {
		return list;
	}
	public void setList(List<Product> list) {
		this.list = list;
	}
	
	Properties p=new Properties();

	public ProductListBean()
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");

	}
	
	public String submit() throws NamingException {
		 System.out.println("Length of array is "+arr.length);
//		 Context ctx=new InitialContext(p);
//			ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
//			int x = 0;
//
//			listProduct = pbr.displayProduct(x);
//			
//			if(!listProduct.isEmpty())
//			{
//					Product p=pbr.searchProduct(x);
//					sum = (float) (sum+p.productPrice);	
//					FacesContext fc = FacesContext.getCurrentInstance();
//					ExternalContext ec=fc.getExternalContext();
//					HttpSession hps=(HttpSession) ec.getSession(false);
//					hps.setAttribute("sum", sum);
//					
//					System.out.println("Sum: "+sum);
			return "Cart";
//			}else
//				return "FailSearch";
	    }
	
	
	public String read() throws NamingException
	{
		Context ctx=new InitialContext(p);
		ProductBeanRemote pbr=(ProductBeanRemote) ctx.lookup("ProductBean/remote");
		

		this.list=pbr.readAllProducts();
		if(this.list!=null)
		{
			return "ReadProduct";
		}else
			return "FailSearch";
	}
}
