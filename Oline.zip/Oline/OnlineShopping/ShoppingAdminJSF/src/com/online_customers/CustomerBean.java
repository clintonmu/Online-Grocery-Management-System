 package com.online_customers;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

import com.online_product.ProductBeanRemote;

public class CustomerBean {
	String fname;
	String lname;
	String dob;
	String address;
	String email;
	long phnumber;
	String password;
	String retypePassword;
	public String getRetypePassword() {
		return retypePassword;
	}

	public void setRetypePassword(String retypePassword) {
		this.retypePassword = retypePassword;
	}



	String location;
	String doj;
	List<Customer> list=new ArrayList<Customer>();

	

	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhnumber() {
		return phnumber;
	}

	public void setPhnumber(long phnumber) {
		this.phnumber = phnumber;
	}


	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public Properties getP() {
		return p;
	}

	public void setP(Properties p) {
		this.p = p;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}

	
	
	Properties p=new Properties();
	String msg="";
	
	
	public CustomerBean() throws NamingException
	{
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		
	}
	
	public String delete() throws NamingException
	{	Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		Customer cust=Cbr.searchCustomer(this.email);
		if(cust!=null)
		{
			Cbr.deleteCustomer(this.email);
			return "SuccessDeleteCustomer";
		}
		else
			return "FailDelete";
		
	}

	public String add() throws NamingException, SQLIntegrityConstraintViolationException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		System.out.println("Setting details:");
		Customer cust=new Customer();
		cust.setCustomerFName(this.fname);
		cust.setCustomerLName(this.lname);
		cust.setDateOfBirth(this.dob);
		cust.setCustomerAddress(this.address);
		cust.setCustomerEmail(this.email);
		cust.setCustomerPhoneNumber(this.phnumber);
		
		
		if((this.password).equals(this.retypePassword))
		{
			cust.setCustomerPassword(this.password);
		}
		
		//cust.setCustomerLocation(this.location);
		
		Calendar cal=Calendar.getInstance();
		Date d=cal.getTime();
		String newdate=d.getDate()+"-"+(d.getMonth()+1)+"-"+(d.getYear()+1900);
		System.out.println(newdate);
		cust.setDateOfJoin(newdate);
		System.out.println("Details set!");
		
		Customer ct=Cbr.searchCustomer(this.email);
		if(ct==null)
		{
			System.out.println("details:"+this.fname+", "+this.lname);
			Cbr.addNewCustomer(cust);
			msg= "SuccessAddCustomer"; 
		}else{
			msg= "FailAdd";
		}
		System.out.println("returning: "+msg);
		return msg;
	}
	
	
	public String update() throws NamingException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		Customer cust=new Customer();
		cust.getCustomerFName();
		cust.getCustomerLName();
		cust.getDateOfBirth();
		cust.getCustomerAddress();
		cust.getCustomerEmail();
		cust.getCustomerPhoneNumber();
		cust.getCustomerPassword();
		cust.getCustomerLocation();
		cust.getDateOfJoin();
		
		Customer ct=Cbr.searchCustomer(this.email);
		if(ct!=null)
		{
			Cbr.updateCustomer(this.fname, this.lname, this.dob, this.address, this.email, 
					this.phnumber, this.password, this.location, this.doj);
			return "SuccessUpdateCustomer";
		}else
			return "FailUpdate";
	}
	
	public String search() throws NamingException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote Cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		list=Cbr.displayCustomer(this.email);
		
		if(!list.isEmpty())
		{
			return "SuccessSearchCustomer";
		}else
			return "FailSearch";
	}
	
	
	public String loginCustomer() throws NamingException
	{
		String msg="";
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		CustomerBeanRemote cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		
		String val=cbr.ValidateCustomer(this.email, this.password);
			if(val.equals("true"))
			{
				msg="Successful";
				FacesContext fc = FacesContext.getCurrentInstance();
				ExternalContext ec=fc.getExternalContext();
				HttpSession hps=(HttpSession) ec.getSession(false);
				hps.setAttribute("username",this.email);
			}
			else if(val.equals("false"))
			{
				msg="Fail";
			}
			else
			{
				msg="notfound";
			}
		return msg;
	}
	
	public String logout()
	{
		FacesContext fc = FacesContext.getCurrentInstance();
		ExternalContext ec=fc.getExternalContext();
		HttpSession hps=(HttpSession) ec.getSession(false);
		String msg="";
		
		if(hps!=null)

		{
			String x=(String)hps.getAttribute("username");
			if(x!=null)
			{
				hps.removeAttribute("username");
				hps.invalidate();
				msg="LogOut";
			}
		}
		return msg;
	}
	
	
	public String read() throws NamingException
	{
		Context ctx=new InitialContext(p);
		CustomerBeanRemote cbr=(CustomerBeanRemote) ctx.lookup("CustomerBean/remote");
		

		this.list=cbr.readAllCustomers();
		if(this.list!=null)
		{
			return "ReadCustomers";
		}else
			return "FailSearch";
	}


}
