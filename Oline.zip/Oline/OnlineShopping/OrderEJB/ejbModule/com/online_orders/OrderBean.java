package com.online_orders;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 * Session Bean implementation class OrderBean
 */
@Stateless
public class OrderBean implements OrderBeanRemote {

    /**
     * Default constructor. 
     */
    public OrderBean() {
        // TODO Auto-generated constructor stub
    }

    @PersistenceContext(name="OrderUnit")
    EntityManager entityManager;
    
	
	public Order addNewOrder(Order order)
			throws SQLIntegrityConstraintViolationException {
		
		double totprice=order.getTotalPrice();
		double disc=order.getDiscount();
		double totdisc=totprice*(disc/100);
		order.setTotalDiscountPrice(totdisc);
		order.setNetPrice(totprice-totdisc);
		entityManager.persist(order);
		return order;
		
	}

	
	public Order searchOrder(int orderId) {
		// TODO Auto-generated method stub
		Order ord=entityManager.find(Order.class, orderId);
		return ord;
	}

	
	public void deleteOrder(int orderId) {
		entityManager.remove(entityManager.find(Order.class, orderId));
		
	}

	
	public List<Order> readAllOrders() {
		// TODO Auto-generated method stub
		List<Order> allOrders = entityManager.createQuery("FROM SHOPPINGORDERS").getResultList();
		return allOrders;
	}

	@Override
	public Order updateOrder(int orderId, String orderDate
			, String location, double totalPrice, double discount,
			double totalDiscountPrice, double netPrice, String customerEmail) {
		// TODO Auto-generated method stub
		Order ord=entityManager.find(Order.class, orderId);
		if(ord!=null)
		{
			ord.setOrderDate(orderDate);
			ord.setLocation(location);
			ord.setTotalPrice(totalPrice);
			
			//calculating discount
			double disc=discount/100;
			ord.setDiscount(disc);
			
			//calculating discounted price
			totalDiscountPrice=totalPrice*disc;
			ord.setTotalDiscountPrice(totalDiscountPrice);
			
			//calculating net price
			netPrice=totalPrice-totalDiscountPrice;
			ord.setNetPrice(netPrice);
			
			ord.setCustomerEmail(customerEmail);
			
			entityManager.merge(ord);
		}else
		{
			ord=null;
		}
		return ord;	
		
	}


	@Override
	public List<Order> displayOrder(int orderId) {
		@SuppressWarnings("unchecked")
		List<Order> allOrders=entityManager.createQuery("From SHOPPINGORDERS").getResultList();
	
		List<Order> searchResult = new ArrayList<Order>();
		   if(allOrders!=null)
		   {
		   for (Order order:allOrders) 
		   {
		     if(order.getOrderId()==orderId)
		     {
		      searchResult.add(order);
		      }
		   }
		   }
		   return searchResult;
	}
	
	public List<Order> findOrders()
	{
		@SuppressWarnings("unchecked")
		List<Order> orderIds=entityManager.createNativeQuery("Select ORDERID from SHOPPINGORDERS").getResultList();
		return orderIds;
	}

}
