package com.online_product;

import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class ProductEJBClicnt {

	/**
	 * @param args
	 * @throws NamingException 
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NamingException, NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		ProductBeanRemote pbr = (ProductBeanRemote) ctx.lookup("ProductBean/remote");
		
		Product pr=new Product();
		
		System.out.println("ID:");
		int id=Integer.parseInt(br.readLine());
		pr.setProductId(id);
		System.out.println("Name:");
		String name=br.readLine();
		pr.setProductName(name);
		System.out.println("Category");
		String cat=br.readLine();
		pr.setCategory(cat);
		System.out.println("Brand:");
		String brand=br.readLine();
		pr.setProductBrand(brand);
		System.out.println("Description:");
		String desc=br.readLine();
		pr.setProductDescription(desc);
		System.out.println("Quantity:");
		double qty=Double.parseDouble(br.readLine());
		pr.setProductQuantity(qty);
		System.out.println("Price:");
		double price=Double.parseDouble(br.readLine());
		pr.setProductPrice(price);
		System.out.println("Stock Quantity:");
		double stock=Double.parseDouble(br.readLine());
		pr.setProductStockQuantity(stock);
		System.out.println("Date of Addition:");
		String date=br.readLine();
		pr.setDateOfAddition(date);
		pr.setSelected(1);
		
		try {
			pbr.addNewProduct(pr);
		} catch (SQLIntegrityConstraintViolationException e) {
			// TODO Auto-generated catch block
			System.out.println("Duplicate Key");
			e.printStackTrace();
		}
		
		System.out.println("Inserted into Database!");
		
		
	}

}
